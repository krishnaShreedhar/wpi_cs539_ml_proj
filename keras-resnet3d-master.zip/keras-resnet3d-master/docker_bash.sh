nvidia-docker run -it --rm -p 8888:8888 -v ${HOME}/workspace/keras-resnet3d/:/root/workspace -v ${HOME}/Datasets:/root/workspace/data jihong/nvidia-keras bash
