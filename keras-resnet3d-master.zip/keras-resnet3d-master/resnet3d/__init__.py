"""Resnet3d init."""

from .resnet3d import Resnet3DBuilder
